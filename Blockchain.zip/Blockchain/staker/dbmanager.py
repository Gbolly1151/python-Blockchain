
import sqlite3
import os

class dbconnector:
    pass

class sqlconnector(dbconnector):
    def __init__(self):
        self._connection=sqlite3.connect(''.join([os.getcwd(),'\\blockchaindb\\test1.db']))
        self.cursor=self._connection.cursor()

    def set_account(self,address):
        """
          create new account

          :param address: publickey
        """
        self.cursor.execute("""INSERT INTO Accounts VALUES (?,?,?,?); """,(address,10000000000,0,'null'))
        self._connection.commit()

    def get_account(self,publickey):
        obj=self.cursor.execute("""
        SELECT * FROM Accounts WHERE address=?
        """,(publickey,))
        return obj.fetchone()

    def get_accounts(self):
        obj=self.cursor.execute("""
        SELECT * FROM Accounts
        """)
        return obj.fetchall()

    def set_balance(self,address,balance):
        """update balance

           :param address: publickey
           :param balance: new balance to set
        """
        self.cursor.execute("""UPDATE Accounts SET balance=? WHERE address=?; """,(balance,address))
        self._connection.commit()


    def get_balance(self,address):
        """
          :return : balance of the address
        """
        obj=self.cursor.execute("""
        SELECT balance FROM Accounts WHERE address=?
        """,(address,))
        balance=obj.fetchone()
        if balance != None:
            return balance[0]
        return False


    def set_block_header(self,header):
        """
          add new block to chain

          :param block: block in json format
        """
        param=['transaction_root_hash','miner_address','reward','hash','tnum']
        values=tuple([header[key] for key in param])
        self.cursor.execute("""INSERT INTO Blocks VALUES (?,?,?,?,?); """,values)
        self._connection.commit()


    def get_block_header(self,Hash):
        obj=self.cursor.execute("""
        SELECT * FROM Blocks WHERE hash=?
        """,(Hash,))
        return obj.fetchone()

    def get_nonce(self,address):
        return self.get_account(address)[2]

    def set_nonce(self,address,value):
        self.cursor.execute("""UPDATE Accounts SET nounce=? WHERE address=?; """,(value,address))
        self._connection.commit()

    def set_transaction(self,transaction,root):
        """
        add new transaction
        """
        param=['sender','to','amount','fees','nonce','data','hash','signature','tnum']
        values=[transaction[key] for key in param]
        values.insert(0,root)
        self.cursor.execute("""INSERT INTO Transactions VALUES (?,?,?,?,?,?,?,?,?,?); """,tuple(values))
        self._connection.commit()


    def get_transaction(self,Hash):
        obj=self.cursor.execute("""
        SELECT * FROM Transactions WHERE hash=?
        """,(Hash,))
        return obj.fetchone()

    def del_account(self,address):
        self.cursor.execute("""DELETE FROM Accounts WHERE address=?
        """,(address,))
        self._connection.commit()

    def reset(self):
        tables=['Accounts','Transactions','Blocks']
        for table in tables:
            self.cursor.execute("""DELETE FROM Accounts
        """)
            self._connection.commit()

    def remove_block(self,id):
        pass

    def close(self):
        self._connection.close()


t={'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
           'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
            'amount': 1000,
             'fees': 1,
              'nonce': 1,
               'data': '',
                'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                 'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9', 'tnum': 1}

test3={"Privatekey": "3081E1020100022D023CDAA35CF0D644BF615115180027232966D7712689BC54573604B58A10F11D3C05A2274A3810FABC141D21810203010001022C1911A85C84DD9B9C9471ABEEA4F31182DA514B4E57D553C985DBE2006594063AFD077B40E449D4155A709BC102180DDEFEF2DA7E38D3604B3E8DDBF2C132E1F15EC8244EE53D0215294C676FD5CA51448698DCB7D21C658E755175D995021806B74873670CA410DBD7B2A2D6B2938E424D2E59F3126BF5021526C0AC3B34191223444E02A77740F0473A6D4331F502180685167703D1E7CF30BE661AF805E7230F3DBC178AFDC807",
 "Publickey": "3034022D023CDAA35CF0D644BF615115180027232966D7712689BC54573604B58A10F11D3C05A2274A3810FABC141D21810203010001",
  "balance": 0,
 "nonce": 0}


#print(b.create_table('Blocks','transaction_root VARCHAR(32) PRIMARY KEY','staking_address VARCHAR(108)','reward INT','hash VARCHAR(32)','tnum INT'))
#s=sqlconnector()
#s.del_account(t['to'])
#print(s.set_nonce(t['sender'],0))
#print(s.get_nonce(t['sender']))
#print(s.get_transaction('ecb3011a5ea5bc5b9c273b4629d3def1'))
#print(s.reset())
#print(s.set_account("3034022D02043A1E819109377C38C9852D421E321236E9BD2912855907CCD265C4D0D138A22CECE896FD0367505202271B0203010001"))
#print(s.get_account('3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001'))
