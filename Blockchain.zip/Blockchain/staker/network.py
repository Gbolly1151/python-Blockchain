import socket
import json
import queue
import time
from block import Block
from dbmanager import sqlconnector
import sys
sys.path.append('C:\python\Blockchain\staker\concensus')
from concensus.bvalidator import BlockValidator
from concensus.transactionscript import Transfer


class Network:
    """
      set up a server for minting block

      attribute
      ---------
      address
      port
    """
    def __init__(self,address,port,):
        self.address=address
        self.port=port
        self.transactions=queue.Queue()
        self.blocks=queue.Queue()
        self.verified_blocks=queue.Queue()
        self.added_blocks=queue.Queue()
        self.get_request=queue.Queue()
        self.broadcast_nodes=self.get_broadcast_node()

    def process_transaction(self,staking_address):
        """
          process transaction in the queue and
          add new block into blocks queue
        """
        tag='[TRANSACTION PROCESSOR] -'
        block = Block(staking_address)
        block.MAX_BODY_SIZE=320*3
        c=0
        print(f'{tag}  Transaction processor active')
        while True:
            if self.transactions.empty():
                continue
            if (block.SIZE < block.MAX_BODY_SIZE):
                transaction=self.transactions.get()
                block.add_transaction(transaction)
                print(f'{tag} new transaction added {transaction["tnum"]} ')
                print(f'{tag} body size is {block.SIZE}')
            else:
                self.blocks.put(block.build())
                print(f'{tag} New block added {c}')
                c+=1
                new=Block(staking_address)
                block=new
                block.MAX_BODY_SIZE=320*3

    def push_block(self):
        """
          handle blocks in the block queue and add to verified block queue
        """
        tag='[PUSH BLOCK] -'
        BV=BlockValidator()
        invalid_block=0
        print(f'{tag} push block function active')
        while True:
            if self.blocks.empty():
                continue
            block=self.blocks.get()
            if BV.is_valid_block(block):
                self.verified_blocks.put(block)
                print(f'{tag} new verified block added')
            else:
                invalid_block+=1
                print(f'{tag} {inavlid_block} invalid block dectected so far')

    def process_block(self):
        """
          Add new block to database which include;
            adding new transaction details,
            adding new block header,
            update account state using transaction in the block
        """
        tag='[BLOCK PROCESSOR] -'
        db=sqlconnector()
        print(f'{tag} block processor active')
        while True:
            if self.verified_blocks.empty():
                continue
            print(f'{tag} start working on block....')
            block=self.verified_blocks.get()
            header=block['header']
            transactions=block['body']
            root=header['transaction_root_hash']
            db.set_block_header(header)
            print(f'{tag} block header added....')
            Transfer('block',header['miner_address'],header['reward'])
            print(f'{tag} staker address updated...')
            c=0
            for transaction in transactions:
                db.set_transaction(transaction,root)
                Transfer(transaction['sender'],transaction['to'],transaction['amount'])
                c+=1
            print(f'{tag} {c} transaction added')
            self.added_blocks.put(block)
            print(f'{tag} block added for broadcast')


    def receive(self):
        """
          keep server on to serve post request

        """
        tag='[POST SERVER] -'
        message=['transaction','block']
        connection=socket.socket()
        connection.bind((self.address,self.port))
        print(f'{tag} Post server active')
        while True:
            print(f'{tag} waiting for connection')
            connection.listen(5)
            con,addr=connection.accept()
            print(f'{tag} connected to {addr}')
            data=json.loads(con.recv(1024).decode())
            if data['type'] in message:
                payload=data['payload']
                vars(self)[data['type']+'s'].put(payload)
                print(f'{tag} recieved from {payload["sender"]}')
                con.send(f'{tag} recieved'.encode())
            else:
                self.get_request.put((con,addr,data))
                print(f'{tag} new request added')

    def get_server(self):
        """
           serve get request
        """
        tag='[GET SERVER] -'
        s=sqlconnector()
        request_type={'Account':s.get_account,
                     'Balance':s.get_balance}
        print(f'{tag} Get server active')
        while True:
            if self.get_request.empty():
                continue
            con,addr,data=self.get_request.get()
            print(f'{tag} new request gotten')
            request=data['type']
            payload=data['payload']
            if request in request_type.keys():
                print(f'{tag} processing...')
                response=request_type[request](payload)
                res=json.dumps(response)
                con.send(res.encode())
                print(f'{tag} request completed')

    def broadcast(self):
        """
           Broadcast added block to other node
        """
        tag='[BROADCAST PROCESSOR] -'
        print(f'{tag} broadcast function active')
        while True:
            if self.added_blocks.empty():
                continue
            added_block=json.dumps(self.added_blocks.get())
            print(added_block)
            with socket.socket() as s:
                for node in self.broadcast_nodes:
                    try:
                        s.connect(tuple(node))
                        print(f'{tag} sending block to {node}')
                        s.send(added_block.encode())
                    except ConnectionRefusedError:
                        print(f'{tag} no connection found')
                        continue

    def get_broadcast_node(self):
        """
          return list of nodes to broadcast added block
        """
        with open('broadcast.node','r') as f:
            node=json.load(f)
            return node

    def set_broadcast_node(self,node):
        with open('broadcast.node','w') as f:
            try:
                nodes=self.get_broadcast_node()
            except json.decoder.JSONDecodeError :
                nodes=[]
            nodes.append(node)
            json.dump(nodes,f)


