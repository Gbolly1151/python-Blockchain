from util import to_str,to_json
from concensus.tvalidator import TransactionValidator
import copy
from hashlib import md5
import sys

class Block:
    """
      A block contain header and body(which include verified transaction)

    """
    MAX_BLOCK_SIZE=10**6
    MAX_BODY_SIZE=MAX_BLOCK_SIZE-500
    SIZE=0
    def __init__(self,miner_address):
        self.reward=2
        self.transaction_root_hash=None
        self.miner_address=miner_address
        self.hash=None
        self.transactions=[]
        self.tnum=0

    @property
    def header(self):
        return {key:value for key,value in vars(self).items() if key != 'transactions'}

    @property
    def body(self):
        return self.transactions

    def body_size(self):
        size=0
        for transaction in self.transactions:
            size+=sum([len(value) for value in transaction.values()])


    def add_transaction(self,transaction):
        """
          add only valid transaction and update the block fees

          :param transaction: transaction in dict format
        """
        v=TransactionValidator(transaction)
        if v.is_valid_transaction:
            self.reward+=transaction['fees']
            self.tnum+=1
            transaction['tnum']=self.tnum
            self.transactions.append(transaction)
            self.SIZE+=self.sizeof(transaction)

    def sizeof(self,x):
            if isinstance(x,dict):
                x=x.values()
            size=0
            for value in x:
                size+=len(str(value))
            return size

    def __set_hash(self):
        var=to_str(self,['transactions','hash'])
        self.hash=md5(var.encode()).hexdigest()
        return self.hash

    def __set_transaction_root_hash(self):
        copied_transaction=copy.deepcopy(self.transactions)
        copied_transaction=[transaction['hash'] for transaction in copied_transaction ]
        while len(copied_transaction) >= 2:
            x=copied_transaction.pop()
            y=copied_transaction.pop()
            z=md5((x+y).encode()).hexdigest()
            copied_transaction.insert(1,z)
        self.transaction_root_hash=copied_transaction[0]

    def size(self):
        """
          return total size of header and body
        """
        def sizeof(x):
            if isinstance(x,dict):
                x=x.values()
            size=0
            for value in x:
                size+=sys.getsizeof(value)
            return size

        return sizeof(self.header) + sizeof(self.body)


    def build(self):
        """
          contruct a valid block structure

          return: header and body
        """
        self.__set_transaction_root_hash()
        self.__set_hash()
        if self.size() < self.MAX_BLOCK_SIZE:
            return {'header':self.header,'body':self.body}
        raise ValueError('max block size reached')




t1={'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
    'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
     'amount': 1000,
     'fees': 1,
     'nonce': 1,
     'data': '',
     'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
     'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9'}


#print(len(t1['signature']))
#print(b.transactions.pop()['hash'])
#b.build()