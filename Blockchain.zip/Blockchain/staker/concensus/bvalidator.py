import sys
from tvalidator import TransactionValidator
from hashlib import md5
import copy
sys.path.append('C:\python\Blockchain\staker')
from block import Block
from cProfile import run

class BlockValidator:

    MAX_BLOCK_SIZE=10**6

    def __init__(self):
        self.header=None
        self.body=None

    @property
    def has_valid_header(self):
        return all([self.has_valid_reward,self.has_valid_miner_address,self.has_valid_transaction_root,self.has_valid_hash,len(self.body) == self.header['tnum']])

    @property
    def has_valid_body(self):
        body=copy.deepcopy(self.body)
        transactions=[transaction.pop('tnum') for transaction in body ]
        return all([TransactionValidator(transaction).is_valid_transaction for transaction in body]) and self.has_valid_tnum

    @property
    def has_valid_reward(self):
        fees=sum([transaction['fees'] for transaction in self.body])
        return fees+2 == self.header['reward']

    @property
    def has_valid_miner_address(self):
        return len(self.header['miner_address']) == 108

    @property
    def has_valid_transaction_root(self):
        copied_transaction=[transaction['hash'] for transaction in self.body ]
        while len(copied_transaction) >= 2:
            x=copied_transaction.pop()
            y=copied_transaction.pop()
            z=md5((x+y).encode()).hexdigest()
            copied_transaction.insert(1,z)
        return copied_transaction[0] == self.header['transaction_root_hash']

    @property
    def has_valid_hash(self):
        var=[str(value) for key,value in self.header.items()if key != 'hash']
        self.hash=md5(''.join(var).encode()).hexdigest()
        return self.hash == self.header['hash']

    @property
    def has_valid_tnum(self):
        tnum=0
        def increment():
            nonlocal tnum
            tnum+=1
            return tnum
        return all([transaction['tnum'] == increment() for transaction in self.body])

    @property
    def has_valid_size(self):
        """
          return total size of header and body
        """
        def sizeof(x):
            if isinstance(x,dict):
                x=x.values()
            size=0
            for value in x:
                size+=sys.getsizeof(value)
            return size

        return (sizeof(self.header) + sizeof(self.body)) < self.MAX_BLOCK_SIZE

    def is_valid_block(self,block_info):
        self.header=block_info['header']
        self.body=block_info['body']
        return self.has_valid_body and self.has_valid_header



c={'header': {'reward': 6,
              'transaction_root_hash': 'b50bcb3d84211b43c92d94795a9507a3',
               'miner_address': '3034022D02043A1E819109377C38C9852D421E321236E9BD2912855907CCD265C4D0D138A22CECE896FD0367505202271B0203010001',
                'hash': 'b2166d1dbde3b7ee370fc6f71ebe957b', 'tnum': 4},
   'body': [{'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
           'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
            'amount': 1000,
             'fees': 1,
              'nonce': 1,
               'data': '',
                'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                 'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9', 'tnum': 1},
            {'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
             'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
              'amount': 1000,
               'fees': 1,
                'nonce': 1,
                 'data': '',
                  'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                   'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9',
                    'tnum': 2},
             {'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
              'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
               'amount': 1000,
                'fees': 1,
                 'nonce': 1,
                  'data': '',
                   'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                    'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9',
                     'tnum': 3},
              {'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
                'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
                 'amount': 1000,
                  'fees': 1,
                   'nonce': 1,
                    'data': '',
                     'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                      'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9',
                       'tnum': 4}]}


t1={'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
    'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
     'amount': 1000,
     'fees': 1,
     'nonce': 1,
     'data': '',
     'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
     'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9'}

def main():
    t=copy.deepcopy(t1)
    b=Block("3034022D02043A1E819109377C38C9852D421E321236E9BD2912855907CCD265C4D0D138A22CECE896FD0367505202271B0203010001")
    for i in range(200):
        temp=copy.deepcopy(t)
        b.add_transaction(t)
        t=temp
    print(b.size())
    bv=BlockValidator()
    print(bv.is_valid_block(c))

if __name__ == '__main__':
    main()
