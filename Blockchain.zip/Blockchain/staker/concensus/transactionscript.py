"""
This moudle contain series of common transaction script
that can be use to process a particular transaction
"""
import sys
paths=['C:\python\Blockchain\staker']
for path in paths:
    sys.path.append(path)
from dbmanager import sqlconnector

class Transfer:
    """
     A simple transfer script to update account balance
    """
    def __init__(self,From,To,amount):
        self.From=From
        self.To=To
        self.amount=amount
        if self.From == 'block':
            self._update_staker_state()
        else:
            self._update_state()

    def _update_state(self):
        """
        update sender and reciever state in the databse
        """
        db=sqlconnector()
        From_balance=db.get_balance(self.From)
        To_balance=db.get_balance(self.To)
        if not From_balance:
            db.set_account(self.From)
            From_balance=db.get_balance(self.From)
        if not To_balance:
            db.set_account(self.To)
            To_balance=db.get_balance(self.To)
        From_balance= From_balance - self.amount
        To_balance=To_balance + self.amount
        From_nonce=db.get_nonce(self.From)
        db.set_nonce(self.From,From_nonce+1)
        db.set_balance(self.From,From_balance)
        db.set_balance(self.To,To_balance)


    def _update_staker_state(self):
        """
        update staker balance in database
        """
        db=sqlconnector()
        To_balance=db.get_balance(self.To)
        if not To_balance:
            db.set_account(self.To)
            To_balance=db.get_balance(self.To)
        To_balance=To_balance + self.amount
        db.set_balance(self.To,To_balance)


t={'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
           'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
            'amount': 1000,
             'fees': 1,
              'nonce': 1,
               'data': '',
                'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                 'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9', 'tnum': 1}

#Transfer('block',t['to'],2)
#s=sqlconnector()
#print(s.get_account(t['sender']))
#print(s.get_account(t['to']))