from hashlib import md5
from rsa import verify,PublicKey
from rsa.pkcs1 import VerificationError
from base64 import b16decode,b16encode
import json
import sys
paths=['C:\python\Blockchain\staker']
for path in paths:
    sys.path.append(path)
from dbmanager import sqlconnector


class ValidationError(Exception):
    pass

class TransactionValidator:
    def __init__(self,transaction):
        vars(self).update(transaction)
        self._con=sqlconnector()

    @property
    def has_valid_address(self):
        return len(vars(self)['sender']) == 108  or vars(self)['sender'] == 'block'

    @property
    def has_valid_amount(self):
        sender_balance=self._con.get_balance(vars(self)['sender'])
        amount=vars(self)['amount']
        if isinstance(amount,int) and sender_balance:
            return (amount + vars(self)['fees']) <= sender_balance
        return False

    @property
    def has_valid_hash(self):
        compute_data=''.join([str(value) for key,value in vars(self).items() if key not in ['hash','signature','_con']])
        compute_hash=md5(compute_data.encode()).hexdigest()
        return compute_hash == vars(self)['hash']

    @property
    def has_valid_nonce(self):
        nonce=self._con.get_account(vars(self)['sender'])[2]
        return (nonce + 1) == vars(self)['nonce']

    @property
    def has_valid_signature(self):
        der=b16decode(vars(self)['sender'].encode())
        signature=b16decode(vars(self)['signature'].encode())
        signed_message=''.join([str(value) for key,value in vars(self).items() if key not in ['hash','signature','_con']])
        try:
            if verify(signed_message.encode(),signature,PublicKey.load_pkcs1(der,format='DER')) in ['MD5','SHA256']:
                return True
        except VerificationError:
            return False

    @property
    def is_valid_transaction(self):
        if all([self.has_valid_address,self.has_valid_amount,self.has_valid_hash,self.has_valid_signature]):
            return True
        return False




t1={'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
    'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
     'amount': 1000,
     'fees': 1,
     'nonce': 1,
     'data': '',
     'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
     'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9'}

t2={'sender': '3034022D023CDAA35CF0D644BF615115180027232966D7712689BC54573604B58A10F11D3C05A2274A3810FABC141D21810203010001',
 'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
  'amount': 100,
   'fees': 1,
    'nonce': 1,
     'data': '',
      'hash': '187619edebe938021057feb78e899d1a',
       'signature': '0014D18B9E899D285A8664D0E2368C9685CEB1E495060E8F192CDD2A013DAD33C024D50873DA3AA06FB203CD23'}

#e=TransactionValidator(t1)
#print(e.has_valid_address)
#print(e.has_valid_amount)
#print(e.has_valid_hash)
#print(e.has_valid_nonce)
#print(e.has_valid_signature)
#print(e.is_valid_transaction)