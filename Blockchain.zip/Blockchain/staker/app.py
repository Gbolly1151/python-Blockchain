from network import Network
from concurrent.futures import  ThreadPoolExecutor as executor
import sys

class Command:
    """
     staking command      argument       function
    --------------------------------------------
   - stake                address,     run a staking node
                          host address,
                          port

    """


    def stake(self,address,host_address,port):
        """
          start a server to support the blockchain by
          verifying block and earn reward and fees through
          staking

          :param address: staking wallet address
          :param host_address: open host address for other node to connect and serve
                    client request
          :param port: open port for host_address

          e.g
           >>C:\python\Blockchain\staker>app.py stake 3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001 127.0.0.1 7890
        """

        #address='3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001'
        if len(address) == 108 :
            server=Network(host_address,int(port))
            with executor(max_workers=8) as ex:
                tasks=['receive','push_block','process_block','get_server']
                for task in tasks:
                    ex.submit(getattr(server,task))
                ex.submit(server.process_transaction,address)
        else:
            print('Invalid address')

obj=Command()
def command(arg):
    if hasattr(obj,arg[0]):
        if len(arg) == 1:
            return getattr(obj,arg[0])()
        a=arg[1:]
        if a[0] == 'help':
            print(getattr(obj,arg[0]).__doc__ )
            return True
        return getattr(obj,arg[0])(*a)
    elif arg[0]=='help':
        print(obj.__doc__)
    else:
        print('ok')

if __name__ == '__main__':
    try:
        arg=sys.argv[1:]
        command(arg)
    except:
        print('invalid command, use app.py help to check for connand')



