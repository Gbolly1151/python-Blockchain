#from network import Network
import socket

{'header': {'reward': 6,
              'transaction_root_hash': 'b50bcb3d84211b43c92d94795a9507a3',
               'miner_address': '3034022D02043A1E819109377C38C9852D421E321236E9BD2912855907CCD265C4D0D138A22CECE896FD0367505202271B0203010001',
                'hash': 'b2166d1dbde3b7ee370fc6f71ebe957b', 'tnum': 4},
   'body': [{'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
           'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
            'amount': 1000,
             'fees': 1,
              'nonce': 1,
               'data': '',
                'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                 'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9', 'tnum': 1},
            {'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
             'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
              'amount': 1000,
               'fees': 1,
                'nonce': 1,
                 'data': '',
                  'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                   'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9',
                    'tnum': 2},
             {'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
              'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
               'amount': 1000,
                'fees': 1,
                 'nonce': 1,
                  'data': '',
                   'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                    'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9',
                     'tnum': 3},
              {'sender': '3034022D021C270F1A219619C175EFAB06261818B62514138DCD867BECACD458299672E69A51978AE4E25B155A2FD3D4A90203010001',
                'to': '3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001',
                 'amount': 1000,
                  'fees': 1,
                   'nonce': 1,
                    'data': '',
                     'hash': 'ecb3011a5ea5bc5b9c273b4629d3def1',
                      'signature': '015E844396FA3D940417CBEDB519EF3E9268A2DA4487C6B607E151190B792790D08CFC72C0BC6C3E8DFF0EEDD9',
                       'tnum': 4}]}



def test_low_broad():
    with socket.socket() as s:
        host='127.0.0.1'
        port= 7689
        s.bind((host,port))
        print('waiting for connection')
        s.listen(4)
        c,addr=s.accept()
        print(c.recv(1025).decode())

