"""
Utility tool that can be use in system
"""



def to_str(obj,ignore=''):
    if isinstance(ignore,str):
        return ''.join([str(value) for key,value in vars(obj).items() if key != ignore])
    return ''.join([str(value) for key,value in vars(obj).items() if key not in ignore])

def to_json(obj,ignore_key=''):
    if isinstance(ignore,str):
        return json.dumps({key:value for key,value in vars(obj).items() if key != ignore_key })
    return json.dumps({key:value for key,value in vars(obj).items() if key not in ignore_key })





t={"sender": "block",
 "to": "deji",
  "amount": 10,
   "gas_price": 2,
    "gas_limit": 2100,
     "nonce": 3,
      "data": "",
       "hash": "812924322dc8a2612c4d3091c4992bb3",
       "signature": "0153B9A1255F67992864A01BAC2847AA047424FA857B98E4E5F4786B597C2AE484EE88DB0BD493F44B24B3C9F3"}

t1={"sender": "3034022D02043A1E819109377C38C9852D421E321236E9BD2912855907CCD265C4D0D138A22CECE896FD0367505202271B0203010001",
   "to": "deji",
    "amount": 10,
     "gas_price": 2,
      "gas_limit": 2100,
       "nonce": 4, "data": "",
         "hash": "77f11e299f948bb7d31efa503430a14a",
       "signature": "001249C5CF4275528EC046FC9DB7547D6AF73461BF96EF460322140F59526546012E74FD8D48CEB20BC699E939"}

