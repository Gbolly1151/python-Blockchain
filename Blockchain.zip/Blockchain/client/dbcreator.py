import sqlite3

class Blockchain:
    """
    A class to create blockchain databse
    """
    def __init__(self,name):
        self.connection=sqlite3.connect(name)
        self.cursor=self.connection.cursor()
        self.name=name

    def create_table(self,table_name,*attribute):
        attribute=','.join(attribute)
        command=f"""CREATE TABLE {table_name} ({attribute});
              """
        self.cursor.execute(command)

        return command

    def drop_table(self,table_name):
        command=f'DROP TABLE {table_name}'
        self.cursor.execute(command)
        return f'{table_name} dropped'

b=Blockchain('test1.db')
print(b.create_table('Blocks','transaction_root VARCHAR(32) PRIMARY KEY','staking_address VARCHAR(108)','reward INT','hash VARCHAR(32)','tnum INT'))
print(b.create_table('Transactions',
'transaction_root CHAR(32) REFERENCES Blocks(transaction_root)',
'sender VARCHAR(108)',
'receiver CHAR(108)',
'amount INT',
'fees INT',
'nounce INT',
'data TEXT NULL',
'hash VARCHAR(32)',
'signature VARCHAR(90)',
'tnum INT'))
#print(b.drop_table('Account'))
print(b.create_table('Accounts',
'address VARCHAR(108) PRIMARY KEY',
'balance INT',
'nounce INT',
'data TEXT NULL',
))