import json
from hashlib import md5

class Transaction:
    """
     A class to create a simple transaction to transfer
     value between two people

     :param to: public addressof the reciever
     :param amount: amount to sent
     :param sender: sender's wallet address default is block,indicating
                tranasaction for minning
     :param fees: transaction fees
     :param data: payload for transaction to communicate to contract address or
        any address,must be a bytecode
    """
    def __init__(self,amount=0,to='unkown',sender='block',fees=1,data=''):
        self.sender=sender
        self.to=to
        self.amount=amount
        self.fees=1
        self.nonce=None
        self.data=data
        self.hash=None
        self.signature=None

    def send(self):
        """
         method to send transaction to mining node
        """
        pass


    def to_str(self):
        """
         return : list of atrribute to be sign and hash
        """
        return ''.join([str(value) for key,value in vars(self).items() if key not in ['hash','signature']])


    def to_json(self):
        """
         return: json format
        """
        return vars(self)

    def set_hash(self):
        if all([value for key,value in vars(self).items() if key not in ['data','hash','signature']]):
            self.hash=md5(self.to_str().encode()).hexdigest()
            return self.hash
        raise ValueError( 'not all required data are filled')




