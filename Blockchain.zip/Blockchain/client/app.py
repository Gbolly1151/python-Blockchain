import wallet,transaction,network
import sys

def transaction_prompt(func):
    def wrapper(arg):
        walletname=input('from wallet: ')
        to=input('to:')
        amount=int(input('amount: '))
        return func(arg,walletname,to,amount)
    return wrapper

class Command:
    """
    client command      argument       function
    --------------------------------------------
   - createwallet       walletname     create new wallet
   - showwallet         walletname     show all wallet info
   - showbalance        walletname     show wallet balance
   - updatebalance      walletname     refesh balance from network
   - sendtransaction    walletname,    send coin to sender
                        amount,to
    """
    def __init__(self):
        self._wallet=wallet.Wallet()

    def createwallet(self,walletname):
        """
        create a new wallet with the new name if not already created

        :param walletname: the name given to then wallet for proper indentification

        e.g
           >>C:\python\Blockchain\client>app.py createwallet test
        """
        print('creating wallet.....')
        status=self._wallet.create(walletname)
        print(status)


    def showwallet(self,walletname):
        """
        show info of the named wallet

        :param walletname: the name of the wallet

        e.g
          >>C:\python\Blockchain\client>app.py showwallet test
        """
        if self._wallet.import_keys(walletname) != 'file not found':
            for key,value in vars(self._wallet).items():
                print('\n',key,':',value,)
        else:print('file not found')


    def showbalance(self,walletname):
        """
        show wallet balance

        :param walletname: the name of the wallet

        e.g
          >>C:\python\Blockchain\client>app.py showbalance test
        """
        if self._wallet.filename == walletname:
            print(f'balance: {self._wallet.balance}')
        elif self._wallet.import_keys(walletname) != 'file not found':
            print(f'balance: {self._wallet.balance}')
        else:print('file not found')

    def updatebalance(self,walletname):
        """
        update balance from network

        :param walletname: the name of the wallet

        e.g
          >>C:\python\Blockchain\client>app.py updatebalance test
        """
        pass

    @transaction_prompt
    def sendtransaction(self,walletname,to,amount):
        """
        transfer coin from one person to another

        :param walletname: the name of the wallet
        :param to: reciever
        :param amount: amount

        e.g
          >>C:\python\Blockchain\client>app.py sendtransaction
          from wallet: test6
          to:3034022D0287BC896810A1AF66655FF9D393BE6C62279A6F51B669A528058981F867BD420E0DAD85D61EB98F40A537C7190203010001
          amount: 1000
        """
        w=wallet.Wallet()
        w.import_keys(walletname)
        t=transaction.Transaction(amount=amount,to=to,sender=w.publickey)
        w.sign(t)
        n=network.Network()
        data=t.to_json()
        n.send('transaction',data)
        print(f'[transaction hash] - {data["hash"]}')

    def addnode(self,address,port):
        """
         adding a staking node
        """
        n=network.Network()
        n.add_node((address,port))
        print('sucessfully added')



obj=Command()
def command(arg):
    if hasattr(obj,arg[0]):
        if len(arg) == 1:
            return getattr(obj,arg[0])()
        a=arg[1:]
        if a[0] == 'help':
            print(getattr(obj,arg[0]).__doc__ )
            return True
        return getattr(obj,arg[0])(*a)
    elif arg[0]=='help':
        print(obj.__doc__)
    else:
        print('ok')

if __name__ == '__main__':
    try:
        arg=sys.argv[1:]
        command(arg)
    except:
        print('invalid command, use app.py help to check for connand')


