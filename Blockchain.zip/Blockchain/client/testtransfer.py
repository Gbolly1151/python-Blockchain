import wallet

class Test:

    def test_update(self):
         w=wallet.Wallet()
         w.import_keys('test')
         g=w.update()
         return g #w.balance

#print(Test().test_update())
