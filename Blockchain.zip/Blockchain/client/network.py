import socket
import json
from queue import Queue

class Network:
    """
     class to create connection for either minting or client wallet

     attribute
     ---------
     connection : contain list of tuple of host and port e.g ('127.0.0.1',8080)
     message : message format to be sent to node
    """
    def __init__(self):
        self.connections=Queue()
        for c in self.get_node():
            self.connections.put(c)
        self.message={'request':None,
                       'type':None,
                        'payload':None}

    def get_node(self):
        """
          return list of nodes to broadcast added block
        """
        with open('staking.node','r') as f:
            node=json.load(f)
            return node

    def add_node(self,node):
        with open('staking.node','w') as f:
            try:
                nodes=self.get_node()
                print('node')
            except json.decoder.JSONDecodeError :
                nodes=[]
            nodes.append(node)
            json.dump(nodes,f)


    def send(self,request,payload,method='POST'):
        """
          send a post request to minting node

          :param request: kind of request in payload e.g transaction or block
          :param payload: the request itself in json format
        """
        self.get(request,payload,method=method)

    def get(self,request,payload,method='GET'):
        """
          this method is use to make get request from a node

          :param request: kind of request in payload e.g address or blockchain
          :param payload: additional info reqiure for request

          >>>n=Network()
          >>>print(n.get('address','3474769fmncx8hi1iygqh........kedh'))
          >>>

        """
        message_format=self.message.copy()
        message_format['request']=method
        message_format['type']=request
        message_format['payload']=payload
        sent=False
        num_of_try=4
        addr,port=self.connections.get()
        self.connections.put((addr,port))
        data=None
        while not sent and num_of_try > 0:
            try:
                with socket.socket() as s:
                  print(f'trying {addr} {port}')
                  s.connect((addr,int(port)))
                  s.send(json.dumps(message_format).encode())
                  data=s.recv(1024).decode()
                  print()
                  sent=True
                  print(f'message sent using {addr} {port}')
            except ConnectionRefusedError as e:
                addr,port=self.connections.get()
                self.connections.put((addr,port))
                num_of_try-=1
                print(e)

        return data


