from rsa import key,sign,PrivateKey,verify,PublicKey
import os
import sys
import json
from base64 import b16encode,b16decode
from network import Network

class Wallet:
    def __init__(self):
        self.privatekey=None
        self.publickey=None
        self.balance=None
        self.nonce=None
        self.filename=None
        self.updated=False

    def create(self,walletname):
        """
         Create a new wallet address pairs i.e
         publickey and private key using RSA encrytion scheme.
         it replace privatekey and publickey value

        """
        wallets=os.listdir(os.path.join(os.getcwd(),'wallet'))
        if walletname+'.gb' in wallets:
            return 'name already exist'
        self.balance=0
        self.nonce=0
        self.filename=walletname
        pub,priv=key.newkeys(354)
        self.publickey,self.privatekey=b16encode(pub.save_pkcs1(format='DER')).decode(),b16encode(priv.save_pkcs1(format='DER')).decode()
        self.export_keys(walletname)
        return walletname+' created'

    def import_keys(self,filename):
        """Load existing pair keys
         from the filesystem and set the private and public key
         with the new keys imported

         :param filename: name of file to import without extension
        """
        try:
            with open(''.join(['wallet/',filename+'.gb']),'r') as f:
                keys=json.load(f)
                self.privatekey,self.publickey,self.balance,self.nonce=keys.values()
            self.filename=filename
            self.updated=False
            return 'imported'
        except FileNotFoundError:
            return 'file not found'



    def export_keys(self,filename):
        """
         Save publickey pair into filename.gb file

         :param filename: filename to store keys in b64 encoded formart
        """
        if not all([self.privatekey,self.publickey]):
            return 'keys are None'
        keys={'Privatekey':self.privatekey,
            'Publickey':self.publickey,
            'balance':self.balance,
            'nonce':self.nonce}
        with open(''.join(['wallet/',filename+'.gb']),'w') as f:
            json.dump(keys,f)
        return 'saved'

    def sign(self,message):
        """sign transaction or message using private key

        :param message: the message to sign
        :return: signature.
        """
        if not self.updated:self.update()
        der=b16decode(self.privatekey.encode())
        if hasattr(message,'signature'): #when message is a transaction
            self.nonce += 1
            self.export_keys(self.filename)
            message.nonce=self.nonce
            message.set_hash()
            message.signature=b16encode(sign(message.to_str().encode(),PrivateKey.load_pkcs1(der,format='DER'),'MD5')).decode()
            return 'signed'
        return b16encode(sign(message.encode(),PrivateKey.load_pkcs1(der,format='DER'),'MD5')).decode()

    def update(self):
        """update balance and nonce from full node
        """
        n=Network()
        account=n.get('Account',self.publickey)
        if account:
            account=json.loads(account)
            self.balance=account[1]
            self.nonce=account[2]
            self.export_keys(self.filename)
            self.import_keys(self.filename)
            self.updated=True






